Programming assignment 2

The code consists of two files: FordFulkerson.py which contains the algorithm and all the functions,
and graph.py which contains the same graph definition as the file in moodle.

How to run:
1. Open FordFulkerson.py
2. Scroll to the bottom and change the following values
2.1 GRAPH_FILE: Filename/path to a file containing the definition of the graph
2.2 TESTSET_FILE: Filename/path to a file containing the definition of the testset
3. Run FordFulkerson.py

The outputs:
If everything went well three things should have been outputted:
1. the whole contents of "f"
2. result of comparing source and sink flow magnitudes
3. the magnitude of flow at sink

The last two are calculated in function called "CheckFlowMagnitude".
