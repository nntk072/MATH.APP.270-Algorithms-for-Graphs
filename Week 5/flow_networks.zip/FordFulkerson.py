#! /usr/bin/env python

from graph import Graph
from copy import deepcopy as copy
from typing import Dict, List, Tuple


def ReadNodes(filename) -> List[int]:
    """Read a set containing vertices."""
    with open(filename, 'r') as ff:
        line = str(ff.readlines()[0])
        values = line.split()

    S: List[int] = []

    for i in values:
        S.append(int(i))

    return S


def CheckFlowMagnitude(s: int, t: int, f: Dict[Tuple[int, int], float]):
    """Optional function that calculates and checks flow magnitudes"""
    source_flow_magnitude = 0.0
    sink_flow_magnitude = 0.0

    for (u, v) in f:
        if u == s:
            source_flow_magnitude += f[(u, v)]

        if v == t:
            sink_flow_magnitude += f[(u, v)]

    if source_flow_magnitude != sink_flow_magnitude:
        print('ERROR: Source and sink flows dont match!!')
        return

    print('Source and sink flows match!')
    print('Flow magnitude is', str(sink_flow_magnitude))

    # Also check that all other vertices have flow magnitude of 0
    flow_magnitudes: Dict[int, float] = {}
    for (u, v) in f:
        if u not in flow_magnitudes:
            flow_magnitudes[u] = 0.0

        if v not in flow_magnitudes:
            flow_magnitudes[v] = 0.0

        flow_magnitudes[u] -= f[(u, v)]
        flow_magnitudes[v] += f[(u, v)]

    for vertex in flow_magnitudes:
        if vertex == s or vertex == t:
            continue

        if flow_magnitudes[vertex] != 0.0:
            print('Flow magnitude is not 0.0 in vertex', str(vertex))


def SumFlow(f1: Dict[Tuple[int, int], float], f2: Dict[Tuple[int, int], float]) -> \
        Dict[Tuple[int, int], float]:
    """Add the flows in f1 and f2."""
    f = copy(f1)

    for (u, v) in f2:
        if not (u, v) in f:
            f[(u, v)] = f2[(u, v)]
        else:
            f[(u, v)] += f2[(u, v)]

    return f


def MakeResidual(G: Graph, f: Dict[Tuple[int, int], float]) -> Graph:
    """Form the residual network."""
    Gr = copy(G)

    for (u, v) in f:
        c = 0

        # Copy the weight
        if (u, v) in Gr.W:
            c = Gr.W[(u, v)]

        # calculate residual capasity
        cf = c - f[(u, v)]

        if v not in Gr.AL[u]:
            Gr.addEdge(u, v)

        Gr.W[(u, v)] = cf

    return Gr


def FormPath(s: int, t: int, parents: Dict[int, int]) -> Tuple[List[int], int]:
    """Forms a path by knowing the parents of each node which was gathered during BFS"""
    counter = 0
    current = t
    parent = parents[current]
    path: List[int] = [current, parent]

    # Check for straigh connection from s to t
    if parent == s and current == t:
        counter += 1
        return ([s, t], counter)

    while parent != s:
        counter += 1
        current = parent
        parent = parents[current]
        path.append(parent)

    path.reverse()
    return (path, counter)


def FindAugPath(Gr: Graph, s: int, t: int) -> Tuple[List[int], int]:
    """Finds augmented path from s to t"""
    counter = 0  # a counter to see how many edges are processed in total
    visited = []  # list of visited vertices
    queue: List[int] = []
    parents: Dict[int, int] = {}  # parents of vertices

    # Mark the source node as visited and enqueue it
    queue.append(s)
    visited.append(s)

    # BFS
    while queue:
        u = queue.pop(0)
        adjacent = Gr.adj(u)

        for v in adjacent:
            counter += 1

            # Check that v has not been visited in this run and has capacity
            if v not in visited and Gr.W[(u, v)] > 0:
                queue.append(v)
                visited.append(v)
                parents[v] = u

                if v == t:
                    (path, formPathsCounter) = FormPath(s, t, parents)
                    counter += formPathsCounter
                    return (path, counter)

    return ([], counter)


def MakeAugFlow(Gr: Graph, s: int, t: int, path: List[int]) -> Dict[Tuple[int, int], float]:
    """Makes augmented flow"""
    f: Dict[Tuple[int, int], float] = {}

    # When path doesn't exists, don't do anything
    if not path:
        return f

    # Handle errors
    if path[0] != s:
        raise Exception("Path not from s")

    if path[-1] != t:
        raise Exception("Path not to t")

    # The minimum capacity on the path, set on infinity for starters
    cfp = float('inf')

    # Figure out cfp from the path
    u = s
    for v in path:
        # Skip loops and first
        if v == u:
            continue

        # Get capacity of the edge
        w = Gr.W[(u, v)]
        u = v

        if w < cfp:
            cfp = w

    # Set the new cfp values into f
    u = s
    for v in path:
        # Skip loops and first
        if v == u:
            continue

        f[(u, v)] = cfp
        f[(v, u)] = -cfp
        u = v

    return f


def FordFulkerson(G: Graph, s: int, t: int):
    """Main function"""
    counter = 0  # a counter to see how many edges are processed in total
    f: Dict[Tuple[int, int], float] = {}

    # Find the first augmented path
    (p, edgesProcessed) = FindAugPath(G, s, t)
    counter += edgesProcessed

    # Get augmented flow for the path and add it to the previous
    augFlow = MakeAugFlow(G, s, t, p)
    f = SumFlow(f, augFlow)

    residual = MakeResidual(G, f)

    i = 0
    while p and i < 1000:
        i += 1

        # Find the next augmented path
        (p, edgesProcessed) = FindAugPath(residual, s, t)
        counter += edgesProcessed

        # Get augmented flow for the path and add it to the previous
        augFlow = MakeAugFlow(residual, s, t, p)
        f = SumFlow(f, augFlow)

        residual = MakeResidual(G, f)

    print("edge count: " + str(counter))
    return f


if __name__ == "__main__":
    GRAPH_FILE = "./testing_data/test_flow_simple_5"
    TESTSET_FILE = "./testing_data/testset_simple_5"

    G = Graph(GRAPH_FILE)
    S = ReadNodes(TESTSET_FILE)
    s = S[0]
    t = S[1]
    f = FordFulkerson(G, s, t)
    print('f:', f)
    # The below function calculates the flow magnitude and checks that the total flow
    # in and out of all vertices, except s and t, is 0.0
    CheckFlowMagnitude(s, t, f)
