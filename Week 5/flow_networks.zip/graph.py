#! /usr/bin/env python

from typing import Dict, List, Tuple


class Graph:
    """
    Graph Class Definition with no implementation
    to be used as a template for Graph Algorithms course
    """

    def __init__(self, filename=None):
        """ class initializer """
        # initialize to empty graph
        # Placeholder for keys to vertices
        self.V: set[int] = set([])
        # number of vertices
        self.nV = 0
        # number of edges
        self.nE = 0
        # Placeholder for adjacency matrix
        self.AM = {}
        # Placeholder for adjacency list.
        self.AL: Dict[int, List[int]] = {}
        # placeholder for weight
        self.W: Dict[Tuple[int, int], float] = {}

        if filename:
            self.readfile(filename)

    def addVertex(self, k: int) -> None:
        """Add vertex k to graph"""
        if k in self.V:
            return

        # Add an element to the vertex set
        self.AL[k] = []
        self.V.add(k)

    def addEdge(self, u: int, v: int, w: float | None = None) -> None:
        """Add edge between vertices u and v with optional weight w"""
        # first we check that u is a vertex
        if u not in self.V:
            ermsg = str(u) + ' not a vertex'
            raise KeyError(ermsg)

        # if v is not a vertex:
        if v not in self.V:
            ermsg = str(v) + ' not a vertex'
            raise KeyError(ermsg)

        # This code is for adjacency list.
        if u not in self.AL:
            self.AL[u] = []

        self.AL[u].append(v)

        # Adjust the weight
        if w is not None:
            self.W[(u, v)] = w

    def adj(self, u: int) -> List[int]:
        """Return an iterable of elements adjacent to u"""
        if u in self.AL:
            return self.AL[u]
        else:
            return []

    def isAdj(self, u: int, v: int) -> bool:
        """Return true if (u,v) is an edge"""
        if u not in self.V:
            ermsg = str(u) + ' not a vertex'
            raise KeyError(ermsg)

        if v not in self.V:
            ermsg = str(v) + ' not a vertex'
            raise KeyError(ermsg)

        return v in self.AL[u]

    """ input method for files """
    def readfile(self, filename):
        with open(filename, 'r') as ff:
            for ll in ff.readlines():
                try:
                    u = int(ll.split(':')[0].strip())
                except:
                    continue

                if u not in self.V:
                    self.addVertex(u)

                for vv in ll.split(':')[1].split():
                    try:
                        v = int(vv)
                    except:
                        uv = vv.strip('()').split(',')
                        v = int(uv[0])
                        w = float(uv[1])
                        self.addVertex(v)
                        self.addEdge(u, v, w)
                        continue

                    if v not in self.V:
                        self.addVertex(v)

                    self.addEdge(u, v)

    def writefile(self, filename):
        with open(filename, 'w') as ff:
            i = 0
            weighted = False

            if self.W:
                weighted = True

            for u in self.V:
                i += 1
                ff.write(str(u))
                ff.write(": ")

                for v in self.AL[u]:
                    if not weighted:
                        ff.write(str(v))
                    else:
                        ff.write("(" + str(v) + "," + str(self.W[(u, v)]) + ")")
                    ff.write(" ")

                if (i < len(self.V)):
                    ff.write('\n')


""" Testcode for when this is run as Main: """
if __name__ == "__main__":
    g = Graph('testgraph')
    print(g.V)
    print(g.AL)
    g2 = Graph('testgraph_weighted')
    print(g2.W)
    g.writefile('test_copy')
